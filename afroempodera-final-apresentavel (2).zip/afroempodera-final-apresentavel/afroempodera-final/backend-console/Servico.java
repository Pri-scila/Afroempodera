public class Servico {
    private String nomeServico;

    public Servico(String nomeServico) {
        this.nomeServico = nomeServico;
    }

    public String getNomeServico() { return nomeServico; }
}